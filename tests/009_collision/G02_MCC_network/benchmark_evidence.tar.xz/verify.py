import csv, json, subprocess, sys
from collections import defaultdict
from pathlib import Path

root = Path(__file__).resolve().parent
subprocess.run([sys.executable, root/'history/verify.py'], check=True)
def read(p):
    with p.open(encoding='utf-8-sig') as f:
        return list(csv.DictReader(f))
old = defaultdict(lambda: defaultdict(list))
for r in read(root/'warpx_runs.csv'):
    old[(r['model'],r['Td'])][r['engine']].append(float(r['seconds']))
assert len(old) == 9
for case, times in old.items():
    assert len(times['G02']) == len(times['WarpX']) == 3
    print('Original', *case, 'WarpX / G02:', round(sum(times['G02'])/sum(times['WarpX']),3))
groups = defaultdict(list)
rows = read(root/'timings.csv')
assert len(rows)==24
for r in rows:
    folder = root/r['folder']
    a,b = [json.loads((folder/(v+'.csv.json')).read_text()) for v in ('baseline','candidate')]
    assert (a['wall_s'], b['wall_s']) == (float(r['before_s']),float(r['after_s']))
    for suffix in ('.csv','.csv.state'):
        assert (folder/('baseline'+suffix)).read_bytes() == (folder/('candidate'+suffix)).read_bytes()
    assert all(a[k]==b[k] for k in ('real_events','candidates','births_measured','births_total'))
    groups[(r['batch'],r['group'],r['model'],r['Td'])].append((a['wall_s'],b['wall_s']))
assert len(groups)==12
for (batch,group,model,td), times in groups.items():
    assert len(times)==(3 if group=='main' else 1)
    before,after = map(sum,zip(*times))
    print(batch,group,model,td,'Td:', '%.3fx, %.2f%% less time' % (before/after,100*(1-after/before)))
path=root/'checks'
for name in ('history.csv','collision_counts.csv','distribution.csv'):
    assert (path/'before'/name).read_bytes()==(path/'after'/name).read_bytes()
assert '100% tests passed, 0 tests failed out of 20' in (path/'ctest.log').read_text()
print('Collision box output matched; see checks/ctest.log for the module tests.')

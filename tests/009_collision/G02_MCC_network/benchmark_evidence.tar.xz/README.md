# PR 数字怎样核对
在解压目录运行 python3 verify.py，无需重新运行模拟。脚本直接比较历史文件，并从实际计时重新计算初始九个工况与 PR 三个工况的加速比。
- warpx_runs.csv：起点，每行从一次 G02 或 WarpX 运行的元数据摘录。窗口 50,000 步，时间步 0.05 ps，分别合并同一工况的三次运行再比较每秒步数。
- timings.csv：本次 PR 的逐对计时，first 为原表，repeat 为独立复测；main 用于主表，reverse 单列。单位为实际秒数，均来自对应的运行 JSON。timings/ 按批次和配对保存两版的诊断 CSV、最终状态和计时元数据。
- history/pairs.csv：历次试改的逐对索引。history/raw/ 提供当时写出的两份过程文件和两份最终粒子状态文件，history/verify.py 单独核对历史部分。
- checks/：模块测试日志（省略两行机器本地路径）、弹性碰撞盒的两版输出。图 1 的 800 点绘图数据仍直接在仓库中提供。

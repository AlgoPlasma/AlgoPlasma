# G02 历史七轮输出
解压后运行 python3 verify.py。无需安装 AlgoPlasma。每一行 pairs.csv 对应一次同工况、同种子、同一轮的前后比较。原始归档位置保留在 source_before 和 source_after 列。本包不含运行时长，也不用于重算加速比。raw/ 内是每次当时写出的诊断 CSV 及最终粒子状态二进制文件。每个 before、after 文件都分别从原始路径复制。

from pathlib import Path
from collections import Counter
import csv
import hashlib

root = Path(__file__).resolve().parent
with (root / 'pairs.csv').open() as f:
    rows = list(csv.DictReader(f))
groups = Counter()
keys = set()
cases = {('he_full', t) for t in (20, 50, 200)} | {('he_noion', t) for t in (20, 50, 200)} | {('reid', t) for t in (1, 12, 24)}
expected = {(n, gas, td, seed) for n in range(1, 8) for gas, td in cases for seed in (104729, 130363, 155921)}
for row in rows:
    key = (int(row['round']), row['gas'], int(row['Td']), int(row['seed']))
    if key in keys:
        raise SystemExit(f'Duplicate pair: {key}')
    keys.add(key)
    for suffix, name in [('.csv', 'csv'), ('.csv.state', 'state')]:
        a, b = [(root / row['folder'] / (side + suffix)).read_bytes() for side in ('before', 'after')]
        if not a or a != b or hashlib.sha256(a).hexdigest() != row[name + '_sha256']:
            raise SystemExit(f'Mismatch: {key}, {name}')
    groups[key[0]] += 1
if keys != expected:
    raise SystemExit('Case, seed or round missing or unexpected')
print('Matched pairs per round:', sorted(groups.items()))
print(f'{len(keys)} pairs: all diagnostic files and all final states matched byte for byte.')
